using System.Runtime.CompilerServices;

namespace hesap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sayi1, sayi2;
            int sonuc = 0;
            sayi1 = Convert.ToInt32(textBox1.Text);
            sayi2 = Convert.ToInt32(textBox2.Text);
            sonuc = sayi1 + sayi2;
            label3.Text = sonuc.ToString();
            this.BackColor = Color.Gold; this.ForeColor = Color.DarkBlue;
        } //button toplama

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sayi1, sayi2;
            int sonuc = 0;
            sayi1 = Convert.ToInt32(textBox1.Text);
            sayi2 = Convert.ToInt32(textBox2.Text);
            sonuc = sayi1 - sayi2;
            label3.Text = sonuc.ToString();
            this.BackColor = Color.Red; this.ForeColor = Color.Yellow;
           
         
        } 
        //button ��karma
        

        private void button4_Click(object sender, EventArgs e)
        {
            int sayi1, sayi2;
            int sonuc = 0;
            sayi1 = Convert.ToInt32(textBox1.Text);
            sayi2 = Convert.ToInt32(textBox2.Text);
            sonuc = sayi1 * sayi2;
            label3.Text = sonuc.ToString();
            this.BackColor = Color.Gray; this.ForeColor = Color.DarkCyan;
        } //button �arpma

        private void button3_Click(object sender, EventArgs e)
        {
            int sayi1, sayi2;
            int sonuc = 0;
            sayi1 = Convert.ToInt32(textBox1.Text);
            sayi2 = Convert.ToInt32(textBox2.Text);
            sonuc = sayi1 / sayi2;
            label3.Text = sonuc.ToString();
            this.BackColor = Color.Green; this.ForeColor = Color.Purple;
        } //button b�lme
    
    }
}
